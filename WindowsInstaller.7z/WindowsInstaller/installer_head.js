
// === ActiveX ===
var activeX = [];
function callActiveX(AXName) {
  if (typeof activeX[AXName] === 'undefined') activeX[AXName] = new ActiveXObject(AXName);
  return activeX[AXName];
}

function fso() { return callActiveX("Scripting.FileSystemObject"); }
function wsh() { return callActiveX("WScript.Shell"); }
function sha() { return callActiveX("Shell.Application"); }



var jsCrLf='\r\n';
var jsOKOnly = 0, jsOKCancel = 1, jsAbortRetryIgnore = 2, jsYesNoCancel = 3, jsYesNo = 4, jsRetryCancel = 5, jsCancelTryAgainContinue = 6,
    jsStop = 16, jsQuestion = 32, jsExclamation = 48, jsInformation = 64,
    jsDefault2ndButton = 256, jsDefault3rdButton = 512,
    jsModal = 4096, jsRightAlignText = 524288, jsRightToLeftText = 1048576,
    jsTimeOut = -1,
    jsOK = 1, jsCancel = 2, jsAbort = 3, jsRetry = 4, jsIgnore = 5, jsYes = 6, jsNo = 7, jsTryAgain = 10, jsContinue = 11;


// BrowseForFolder WINDOW_OPTIONS (3rd parameter) can be combined with | or +
var BIF_RETURNONLYFSDIRS= 0x0001, // The default
    BIF_DONTGOBELOWDOMAIN=0x00000002,
    BIF_STATUSTEXT=0x00000004,
    BIF_RETURNFSANCESTORS=0x00000008,
    BIF_EDITBOX=0x00000010,
    BIF_VALIDATE=0x00000020,
    BIF_NEWDIALOGSTYLE=0x00000040,
    BIF_BROWSEINCLUDEURLS=0x00000080,
    BIF_USENEWUI=BIF_EDITBOX | BIF_NEWDIALOGSTYLE,
    BIF_UAHINT=0x00000100,
    BIF_NONEWFOLDERBUTTON=0x00000200,
    BIF_NOTRANSLATETARGETS=0x00000400,
    BIF_BROWSEFORCOMPUTER=0x00001000,
    BIF_BROWSEFORPRINTER=0x00002000,
    BIF_BROWSEINCLUDEFILES=0x00004000,
    BIF_SHAREABLE=0x00008000,
    BIF_BROWSEFILEJUNCTIONS=0x00010000;

// Filesystem
var ForReading = 1,
  ForWriting = 2,
  ForAppending = 8,
  TristateUseDefault = -2, // Ouvre le fichier avec la valeur par défaut du système.
  TristateTrue = -1, // Ouvre le fichier comme de l'Unicode.
  TristateFalse = 0;

// Converti le chemin passé en chemin absolu
function abs_path (str) {
  if (str.length > 2 && str.charAt(0) !== '\\' && str.charAt(1) !== ':') {
    str = fso().GetAbsolutePathName(wsh().CurrentDirectory + '\\' + str);
  } else str = str;

  return str;
}

// Polyfills
String.prototype.basename = function(sep) {
  if (typeof sep === 'undefined') sep = "\\";
  return this.substr(this.lastIndexOf(sep) + 1);
};

String.prototype.dirname = function() {
  return this.replace(/[\\\/][^\\\/]*$/, '');
};


// Renvoie la ligne de commande sous forme de tableau, l'élément 0 du tableau est la commande elle-même, les suivants sont les paramétres
function commandLineToArgs(cl) {
  // cl=document.getElementById("fmgcExtract").commandLine;
  var lag = [];
  var ia = 0;

  for (i = 0; i < cl.length; i++) {
    lag[ia] = "";
    // Passe les espaces en début de chaine
    while (i < cl.length && (cl.charAt(i) === ' ' || cl.charAt(i) === '\t')) i++;

    // Est-ce que la chaine commence par un " ?
    if (cl.charAt(i) === '"') { // Si oui on prend tout jusqu'au prochain "
      while (++i < cl.length && cl.charAt(i) !== '"') lag[ia] += cl.charAt(i);
    } else { // Sinon on prend tout jusqu'au prochain espace
      while (i < cl.length && cl.charAt(i) !== ' ' && cl.charAt(i) !== '\t') lag[ia] += cl.charAt(i++);
    }

    if (lag[ia] === "") lag.pop();
    else ia++;
  }
  return lag;
}

var MYROOT_DIR = fso().GetParentFolderName(document.location.href.substring(8).replace(/\//g, '\\'));
var APP_NAME = "SquidPartnerQt";

var ww = 520, wh = 250;
self.resizeTo(ww, wh);
self.moveTo((screen.width - ww) / 2, (screen.height - wh) / 2);
args = commandLineToArgs(InstDlg.commandLine);

