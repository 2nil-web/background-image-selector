
// Pré-chargement de tous les elements du DOM
function disableSelection(element) {
  if (typeof element.onselectstart != 'undefined') {
    element.onselectstart = function() {
      return false;
    };
  } else if (typeof element.style.MozUserSelect != 'undefined') {
    element.style.MozUserSelect = 'none';
  } else {
    element.onmousedown = function() {
      return false;
    };
  }
}

function getAllNodes() {
  Array.prototype.forEach.call(document.body.querySelectorAll('*'), function(elt) {
    if (typeof elt.tagName !== 'undefined' && elt.tagName.toLowerCase() === 'label') {
      disableSelection(elt);
    }

    if (typeof elt.id !== "undefined" && elt.id !== "") {
      //logElem(elt);

      if (typeof elt.type !== 'undefined' && elt.type === 'text') {
        var min = elt.getAttribute("min");
        var max = elt.getAttribute("max");
        //write_log("id "+elt.id+", type "+elt.type+", typeof min "+typeof min+", typeof max "+typeof max);

        if (typeof min === 'string' || typeof max === 'string') {
          if (isNaN(min)) min = Number.MIN_SAFE_INTEGER;
          else min = Number(min);
          if (isNaN(max)) max = Number.MAX_SAFE_INTEGER;
          else max = Number(max);
          //write_log("id "+elt.id+", type "+elt.type+", min "+min+', type '+typeof min+", max "+max+", type "+typeof max);
          // Allow input of positive integer between min and max
          setIntegerFilter(elt, min, max);
        }
      }

      //InstDlg[elt.id] = document.getElementById('+elt.id+');
      //eval('var ' + elt.id + '=document.getElementById(' + elt.id + ');');
      window[elt.id] = document.getElementById(elt.id);
    }
  });
}

var INST_DIR = wsh().ExpandEnvironmentStrings("%LOCALAPPDATA%") + '\\' + APP_NAME;

function dlgInstFolder(elem) {
  if (elem.value === '') elem.value = INST_DIR;
  if (!fso().FolderExists(elem.value)) fso().CreateFolder(elem.value);
  
  var folder = sha().BrowseForFolder(0, "Select a Folder", BIF_RETURNONLYFSDIRS | BIF_STATUSTEXT | BIF_USENEWUI | BIF_VALIDATE, elem.value);
  if (folder !== null) elem.value = folder.Self.Path;
}

// Sortie par la touche escape (ou le bouton de fermeture de la fenêtre)
function onKeyUp(evt) {
  evt = evt || window.event;
  if (evt.keyCode === 27) window.close();
}

window.onload = function() {
  getAllNodes();
  document.onkeyup = onKeyUp;
  inst_dir.value = INST_DIR;
};

var loaderItv, rotateAngle = 0, angularVelocity=10,
  finishedProcess=true, endMsg;

function inactive_button(elem) {
  elem.disabled=true;
  elem.style.opacity=0.2;
}

function active_button(elem) {
  elem.disabled=false;
  elem.style.opacity=1;
}

function stopProgress () {
  active_button(install);
  active_button(uninstall);
  active_button(browse);
  clearInterval(loaderItv);
  alert(APP_NAME+endMsg);
  window.close();
}

function updateLoader() {
  if (finishedProcess && rotateAngle <= 30) {
    clearInterval(loaderItv);
    loader.setAttribute("style", "transform: rotate(0deg)");
    stopProgress();
  } else {
    rotateAngle -= angularVelocity;
    if (rotateAngle < 0) rotateAngle = 360;
    loader.setAttribute("style", "transform: rotate(" + rotateAngle + "deg)");
  }
}

function startProgress (msg) {
  endMsg=msg;
  inactive_button(install);
  inactive_button(uninstall);
  inactive_button(browse);
  finishedProcess=false;
  loaderItv = setInterval(updateLoader, 10);
}

function DoInstall() {

  startProgress(" installed");

  // Installation process
  var fld;
  if (!fso().FolderExists(inst_dir.value)) fso().CreateFolder(inst_dir.value + '\\');
  fso().CopyFile('squid_partner_qt_ui.exe',  inst_dir.value + '\\', true);

  finishedProcess=true;
}

function DoRemove() {
  startProgress(" removed");

  // Removall process
  if (fso().FolderExists(inst_dir.value)) {
    fso().DeleteFile(inst_dir.value + "\\*", true);
    fso().DeleteFolder(inst_dir.value);
  }

  finishedProcess=true;
}

function CloseAbort() {
  if (finishedProcess || confirm("Sur to abort pending process?\n"+APP_NAME+" configuration state might inconsistent.")) window.close();
}
